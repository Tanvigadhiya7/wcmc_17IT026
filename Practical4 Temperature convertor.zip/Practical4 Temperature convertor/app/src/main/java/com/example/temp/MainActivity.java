package com.example.temp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static android.icu.text.DisplayContext.LENGTH_SHORT;

public class MainActivity extends AppCompatActivity {

    private Button c2f_btn;
    private Button f2c_btn ;
    private EditText user_in;
    private TextView output_view ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        c2f_btn=findViewById(R.id.c2f_btn);
        f2c_btn=findViewById(R.id.f2c_btn);
        user_in=findViewById(R.id.user_in);
        output_view=findViewById(R.id.output_view);

       input();
    }

    private void input() {
        c2f_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
           ConvertorClass x=new ConvertorClass();
           double degcel=Double.parseDouble(user_in.getText().toString());
           double degfar=x.c2f_fn(degcel);
              //  Toast.makeText(getApplicationContext(),String.valueOf(degfar),Toast.LENGTH_SHORT).show();
                String ss = String.valueOf(degfar);
                output_view.setText(ss);
           //output_view.setText(Double.toString(degfar));

            }
        });

        f2c_btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                ConvertorClass x=new ConvertorClass();
                double degfar=Double.parseDouble(user_in.getText().toString());
                double degcel=x.f2c_fn(degfar);
                String tt=String.valueOf(degcel);
                output_view.setText(tt);

            }
        });

    }
}
