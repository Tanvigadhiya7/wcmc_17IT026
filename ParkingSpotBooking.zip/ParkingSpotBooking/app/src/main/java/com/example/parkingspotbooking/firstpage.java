package com.example.parkingspotbooking;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class firstpage extends AppCompatActivity {
    private Button b1;
    ImageView image,road1;
    Animation frombottom,fromtop;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firstpage);

        b1=findViewById(R.id.b1);
        road1=findViewById(R.id.road1);
        image=findViewById(R.id.image);
        frombottom= AnimationUtils.loadAnimation(this,R.anim.frombottom);
        fromtop=AnimationUtils.loadAnimation(this,R.anim.fromtop);
        b1.setAnimation(frombottom);
        image.setAnimation(fromtop);
    }

}
