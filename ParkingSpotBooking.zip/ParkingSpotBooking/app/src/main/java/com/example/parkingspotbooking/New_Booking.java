package com.example.parkingspotbooking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class New_Booking extends AppCompatActivity implements View.OnClickListener {
    private Button r1,r2,r3,r4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new__booking);
        r1=findViewById(R.id.r1);
        r2=findViewById(R.id.r2);
        r3=findViewById(R.id.r3);
        r4=findViewById(R.id.r4);

        findViewById(R.id.r1).setOnClickListener(this);
        findViewById(R.id.r2).setOnClickListener(this);
        findViewById(R.id.r3).setOnClickListener(this);
        findViewById(R.id.r4).setOnClickListener(this);
    }
    public void activity(){
        Intent i = new Intent(this, bookspot.class);
        startActivity(i);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.r1:
                activity();
                break;
/*
            case R.id.r2:
                activity();
                break;

            case R.id.r3:
                activity();
                break;

            case R.id.r4:
                activity();
                break;*/
    }
}
}