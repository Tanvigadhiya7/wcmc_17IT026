package com.example.parkingspotbooking;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.os.Bundle;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    FirebaseAuth mAuth;
    ProgressBar progressBar;

    private EditText et_name, et_pass;
    private Button bt_login, bt_user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();
        et_name = findViewById(R.id.et_name);
        et_pass = findViewById(R.id.et_pass);
        bt_login = findViewById(R.id.bt_login);
        bt_user =findViewById(R.id.bt_user);
        progressBar = findViewById(R.id.progressbar);
        findViewById(R.id.bt_login).setOnClickListener(this);
        findViewById(R.id.bt_user).setOnClickListener(this);


    }

    private void userLogin()
    {
        String email = et_name.getText().toString().trim();
        String pass = et_pass.getText().toString().trim();

        if (email.isEmpty()) {
            et_name.setError("Email is required");
            et_name.requestFocus();
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            et_name.setError("Please enter a valid email");
            et_name.requestFocus();
            return;
        }
        if (pass.isEmpty()) {
            et_pass.setError("Password is required");
            et_pass.requestFocus();
            return;
        }
        progressBar.setVisibility(View.VISIBLE);

        mAuth.signInWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                progressBar.setVisibility(View.GONE);
                if (task.isSuccessful()) {
                    finish();
                    Intent intent = new Intent(MainActivity.this, New_user_login.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (mAuth.getCurrentUser() != null) {
            finish();
            startActivity(new Intent(this, New_user_login.class));
        }
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bt_user:
           
                startActivity(new Intent(this, User_registration.class));
                break;

            case R.id.bt_login:
                userLogin();
                break;

        }
    }
}
