package com.example.parkingspotbooking;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class User_registration extends AppCompatActivity implements View.OnClickListener{

    private FirebaseAuth mAuth;

    ProgressBar progressBar;
    private EditText pt_fullname,pt_phone,pt_email,pt_newpass;
    private Button bt_submit;
    String pattern = "[0-9]{10}";
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    Matcher m;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_registration);
        mAuth = FirebaseAuth.getInstance();
        progressBar = findViewById(R.id.progressbar);
        pt_fullname = findViewById(R.id.pt_fullname);
        pt_email = findViewById(R.id.pt_email);
        pt_newpass = findViewById(R.id.pt_newpass);
        pt_phone = findViewById(R.id.pt_phone);
        bt_submit = findViewById(R.id.bt_submit);
        findViewById(R.id.bt_submit).setOnClickListener(this);
    }
    private void registerUser()
    {
        String name = pt_fullname.getText().toString().trim();
        String phone = pt_phone.getText().toString().trim();
        String email = pt_email.getText().toString().trim();
        String password = pt_newpass.getText().toString().trim();
        if (name.isEmpty()) {
            pt_fullname.setError("Email is required");
            pt_fullname.requestFocus();
            return;
        }
        if (phone.isEmpty()) {
            pt_phone.setError("Phone no. is required");
            pt_phone.requestFocus();
            return;
        }
        if(phone.length()!=10  || phone.matches(pattern)==false  ) {
            pt_phone.setError("Enter valid phone number");
            pt_phone.requestFocus();
            return;
        }
        if (email.isEmpty()) {
            pt_email.setError("Email is required");
            pt_email.requestFocus();
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            pt_email.setError("Please enter a valid email");
            pt_email.requestFocus();
            return;
        }
        if (password.isEmpty()) {
            pt_newpass.setError("Password is required");
            pt_newpass.requestFocus();
            return;
        }



        if (password.length() < 6) {
            pt_newpass.setError("Minimum lenght of password should be 6");
            pt_newpass.requestFocus();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                progressBar.setVisibility(View.GONE);
                if (task.isSuccessful()) {
                    finish();
                    Toast.makeText(getApplicationContext(), "You are successfully registered", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(User_registration.this, New_user_login.class));
                } else {

                    if (task.getException() instanceof FirebaseAuthUserCollisionException) {
                        Toast.makeText(getApplicationContext(), "You are already registered", Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });


    }
    public static boolean isValidPassword(final String pt_newpass) {

        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(pt_newpass);

        return matcher.matches();

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.bt_submit:
                registerUser();
                break;
        }
    }
}
