package com.example.parkingspotbooking;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatRadioButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class bookspot extends AppCompatActivity implements View.OnClickListener {
    private EditText bk_name,et_time,et_durat;

    private RadioButton bt1,bt2,bt3,bt4;
    private int b_state=1;


    private FirebaseDatabase firedb =FirebaseDatabase.getInstance();

    private DatabaseReference root_ref = firedb.getReference();
    private DatabaseReference child_ref = root_ref.child("mes");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookspot);



        bk_name=findViewById(R.id.bk_name);


    }
    public void onRadio(View view)
    {
        boolean isSelected=((Button)view).isPressed();
        switch (view.getId()){
            case R.id.bt1:

                break;
        }
    }

   /* @Override
    protected void onStart(){
        super.onStart();
        child_ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
              String val=dataSnapshot.getValue(String.class);
              int v=Integer.parseInt(val);
               bk_name.setText(val);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }*/
    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.bt1:
                break;

            case R.id.bt2:
                break;

            case R.id.bt3:
                break;

            case R.id.bt4:
                break;
        }

    }
}
