package com.example.practical5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView attempts;
    private EditText name;
    private EditText password;
    private Button login;
    private int counter=3;
    private TextView tv1;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name=(EditText)findViewById(R.id.name);
        password=(EditText)findViewById(R.id.password);
        attempts=(TextView)findViewById(R.id.attempts);
        login=(Button)findViewById(R.id.login);
        tv1=findViewById(R.id.tv1);
        attempts.setText("no. of attempts remaining " + String.valueOf(counter));

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                page(name.getText().toString(),password.getText().toString());

            }
        });
    }

    private void page(String username,String userpassword){

        if((username.equals("tanvi")) && (userpassword.equals("123"))) {

            tv1.setVisibility(View.VISIBLE);
            tv1.setBackgroundColor(Color.GREEN);
            tv1.setText("login successful");


        }
        else{

            counter--;
            tv1.setVisibility(View.VISIBLE);
            tv1.setBackgroundColor(Color.RED);


            attempts.setText("No. of incorrect attempts" + String.valueOf(counter) );

            if(counter==0)
                login.setEnabled(false);

        }
    }
}
